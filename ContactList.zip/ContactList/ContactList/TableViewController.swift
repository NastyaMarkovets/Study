//
//  TableViewController.swift
//  ContactList
//
//  Created by Alexandr Yanski on 10.10.2018.
//  Copyright © 2018 Lonely Tree Std. All rights reserved.
//

import UIKit

struct cellData {
    let cell: Int!
    let text: String!
    let image: UIImage!
}

class TableViewController: UITableViewController {
    
    var contactPerson = [cellData]()
    let contactSections = ["RECENT", "FRIENDS", "FAMILY", "COLLEAGUES", "OTHER"]
//    let contactPerson = ["Alex Yanski", "Elena Markovets", "Nadya Cherepaha", "Nikita Rizhik", "Katya Kundikova", "Ilya Kasper", "Viktoriya Kasper", "Anastasia Sologub", "Olga Voinalovich", "Tanya Markovets", "Leonid Markovets", "Alex Rabko", "Valentina Rabko", "Igor Baranski", "Daria Kelpanovich", "Diana Abramchik", "Maria Kyrlovich"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        contactPerson = [cellData(cell: 1, text: "Alex Yanski", image: UIImage(named: "AppIcon")),
                         cellData(cell: 2, text: "Elena Markovets", image: UIImage(named: "AppIcon")),
                         cellData(cell: 3, text: "Nadya Cherepaha", image: UIImage(named: "AppIcon")),
                         cellData(cell: 4, text: "Nikita Rizhik", image: UIImage(named: "AppIcon")),
                         cellData(cell: 5, text: "Katya Kundikova", image: UIImage(named: "AppIcon")),
                         cellData(cell: 6, text: "Ilya Kasper", image: UIImage(named: "AppIcon")),
                         cellData(cell: 7, text: "Viktoriya Kasper", image: UIImage(named: "AppIcon")),
                         cellData(cell: 8, text: "Anastasia Sologub", image: UIImage(named: "AppIcon")),
                         cellData(cell: 9, text: "Olga Voinalovich", image: UIImage(named: "AppIcon")),
                         cellData(cell: 10, text: "ATanya Markovets", image: UIImage(named: "AppIcon")),
                         cellData(cell: 11, text: "Leonid Markovets", image: UIImage(named: "AppIcon")),
                         cellData(cell: 12, text: "Alex Rabko", image: UIImage(named: "AppIcon")),
                         cellData(cell: 13, text: "Valentina Rabko", image: UIImage(named: "AppIcon")),
                         cellData(cell: 14, text: "Igor Baranski", image: UIImage(named: "AppIcon")),
                         cellData(cell: 15, text: "Daria Kelpanovich", image: UIImage(named: "AppIcon")),
                         cellData(cell: 16, text: "Diana Abramchik", image: UIImage(named: "AppIcon")),
                         cellData(cell: 17, text: "Maria Kyrlovich", image: UIImage(named: "AppIcon")),]
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return self.contactSections.count
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.contactPerson.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("ContactCell", owner: self, options: nil)?.first as! ContactCell
        cell.contactPhotoList.image = contactPerson[indexPath.row].image
        cell.contactLabelList.text = contactPerson[indexPath.row].text
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.contactSections[section] as String
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
}
